# Details

Date : 2024-01-29 08:07:19

Directory c:\\Users\\darry\\Dropbox\\classes21\\comp2404-w24\\assignments-w24\\a2\\a2-complete

Total : 27 files,  1968 codes, 134 comments, 465 blanks, all 2567 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Repos
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Repo.cc](/Repo.cc) | C++ | 63 | 16 | 20 | 99 |
| [Repo.h](/Repo.h) | C++ | 29 | 6 | 13 | 48 |
| [RepoList.cc](/RepoList.cc) | C++ | 70 | 12 | 15 | 97 |
| [RepoList.h](/RepoList.h) | C++ | 26 | 4 | 9 | 39 |
| [Client.cc](/Client.cc) | C++ | 40 | 0 | 9 | 49 |
| [Client.h](/Client.h) | C++ | 21 | 4 | 10 | 35 |
| [Control.cc](/Control.cc) | C++ | 299 | 15 | 32 | 346 |
| [Control.h](/Control.h) | C++ | 35 | 5 | 19 | 59 |
| [Date.cc](/Date.cc) | C++ | 81 | 7 | 23 | 111 |
| [Date.h](/Date.h) | C++ | 32 | 6 | 12 | 50 |
| [Makefile](/Makefile) | Makefile | 33 | 0 | 18 | 51 |
| [TestControl.cc](/TestControl.cc) | C++ | 663 | 23 | 112 | 798 |
| [TestControl.h](/TestControl.h) | C++ | 31 | 3 | 18 | 52 |
| [Tester.cc](/Tester.cc) | C++ | 150 | 3 | 18 | 171 |
| [Tester.h](/Tester.h) | C++ | 34 | 3 | 10 | 47 |
| [File.cc](/File.cc) | C++ | 16 | 0 | 6 | 22 |
| [File.h](/File.h) | C++ | 23 | 3 | 13 | 39 |
| [FileList.cc](/FileList.cc) | C++ | 77 | 3 | 15 | 95 |
| [FileList.h](/FileList.h) | C++ | 26 | 4 | 9 | 39 |
| [View.cc](/View.cc) | C++ | 31 | 0 | 7 | 38 |
| [View.h](/View.h) | C++ | 13 | 0 | 5 | 18 |
| [GetHub.cc](/GetHub.cc) | C++ | 88 | 4 | 11 | 103 |
| [GetHub.h](/GetHub.h) | C++ | 26 | 5 | 14 | 45 |
| [class.py](/class.py) | Python | 36 | 8 | 28 | 72 |
| [defs.h](/defs.h) | C++ | 5 | 0 | 5 | 10 |
| [main.cc](/main.cc) | C++ | 10 | 0 | 7 | 17 |
| [test.cc](/test.cc) | C++ | 10 | 0 | 7 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)