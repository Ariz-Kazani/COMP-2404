# Summary

Date : 2024-01-29 08:07:19

Directory c:\\Users\\darry\\Dropbox\\classes21\\comp2404-w24\\assignments-w24\\a2\\a2-complete

Total : 27 files,  1968 codes, 134 comments, 465 blanks, all 2567 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 25 | 1,899 | 126 | 419 | 2,444 |
| Python | 1 | 36 | 8 | 28 | 72 |
| Makefile | 1 | 33 | 0 | 18 | 51 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 27 | 1,968 | 134 | 465 | 2,567 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)