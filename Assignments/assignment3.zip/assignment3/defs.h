#ifndef DEFS_H
#define DEFS_H

#define MAX_FILES 100
#define MAX_REPOS 100



#endif
